# NEXTNEX IP WEALTH — Full-stack starter

## Included
- PostgreSQL 16 using Docker Compose
- FastAPI backend and Swagger/OpenAPI docs
- SQLAlchemy models: organisations, users, IP assets, valuations and deals
- Starter endpoints: health, IP Wallet asset CRUD basics, valuation create/list
- Next.js + TypeScript dashboard shell showing the 12 planned modules

## Start PostgreSQL
Install Docker Desktop, then from this directory run:
`docker compose up -d db`

Copy `.env.example` to `.env` and replace the sample secrets before use.

## Start API
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
# Set DATABASE_URL in your shell to the value in the root .env
uvicorn app.main:app --reload
```
API: http://localhost:8000 · Docs: http://localhost:8000/docs

## Start frontend
```bash
cd frontend
npm install
npm run dev
```
Frontend: http://localhost:3000

## Important
This is a development foundation, not production-ready. Authentication/JWT issuance, password reset, MFA, tenant isolation, role enforcement, Alembic migrations, file storage, audit trails and real valuation/financing logic remain to be implemented. The initial asset endpoints are intentionally basic and must be protected by authenticated tenant-scoped permissions before real client data is entered. Valuation records are indicative inputs, not certified valuations. Change all sample secrets and do not expose this development server publicly.
