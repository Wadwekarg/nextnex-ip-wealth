from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.database import Base, engine
from app.models.core import Organisation, User, IPAsset, Valuation, Deal
from app.routers import health, assets, valuations

Base.metadata.create_all(bind=engine)
app = FastAPI(title="NEXTNEX IP WEALTH API", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:3000"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
app.include_router(health.router)
app.include_router(assets.router)
app.include_router(valuations.router)

@app.get("/")
def root():
    return {"name": "NEXTNEX IP WEALTH", "api_docs": "/docs"}
