from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.core import IPAsset

router = APIRouter(prefix="/api/assets", tags=["IP Wallet"])

class AssetCreate(BaseModel):
    organisation_id: int = Field(gt=0)
    owner_user_id: int = Field(gt=0)
    title: str = Field(min_length=2, max_length=240)
    ip_type: str
    jurisdiction: str = "India"
    registration_number: str | None = None
    description: str | None = None

@router.get("")
def list_assets(db: Session = Depends(get_db)):
    return db.query(IPAsset).order_by(IPAsset.id.desc()).all()

@router.post("", status_code=201)
def create_asset(payload: AssetCreate, db: Session = Depends(get_db)):
    asset = IPAsset(**payload.model_dump())
    db.add(asset)
    db.commit()
    db.refresh(asset)
    return asset

@router.get("/{asset_id}")
def get_asset(asset_id: int, db: Session = Depends(get_db)):
    asset = db.get(IPAsset, asset_id)
    if asset is None:
        raise HTTPException(status_code=404, detail="IP asset not found")
    return asset
