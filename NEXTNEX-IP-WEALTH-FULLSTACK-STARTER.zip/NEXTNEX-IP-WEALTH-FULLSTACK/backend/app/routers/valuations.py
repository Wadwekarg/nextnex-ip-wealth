from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.core import Valuation

router = APIRouter(prefix="/api/valuations", tags=["Valuation Engine"])

class ValuationCreate(BaseModel):
    asset_id: int = Field(gt=0)
    method: str
    currency: str = "INR"
    estimated_value: float = Field(gt=0)
    assumptions: str | None = None

@router.get("")
def list_valuations(db: Session = Depends(get_db)):
    return db.query(Valuation).order_by(Valuation.id.desc()).all()

@router.post("", status_code=201)
def create_valuation(payload: ValuationCreate, db: Session = Depends(get_db)):
    record = Valuation(**payload.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return record
