import "./style.css";
export const metadata = { title: "NEXTNEX IP WEALTH", description: "Digital infrastructure for intellectual property" };
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="en"><body>{children}</body></html>; }
