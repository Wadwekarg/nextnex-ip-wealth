const modules = [
["IP Wallet","Register and manage patents, trademarks, designs and copyrights"],
["Digital Passport","Structured identity, ownership history and evidence"],
["Valuation Engine","Income, market and cost-based assessments"],
["IP Value Index","Track valuation snapshots and index movement"],
["IP Wealth Score","Assess protection, commercial readiness and risk"],
["Financing Engine","Indicative collateral and financing assessments"],
["Marketplace","Publish assets and manage buyer enquiries"],
["Deal Room","Due diligence, offers and assignment workflows"],
["Monitoring","Renewals, deadlines and risk events"],
["Valuer Portal","Valuation assignments and report submission"],
["Institutional Portal","Financing requests and portfolio review"],
["Administration","Users, roles, configuration and audit trails"]
];
export default function Home(){return <main className="shell"><header><div className="brand"><b>N</b><span><strong>NEXTNEX</strong><small>IP WEALTH™</small></span></div><span className="tag">PLATFORM FOUNDATION · V0.1</span></header><section className="hero"><p>INTELLECTUAL PROPERTY · FINANCIAL INFRASTRUCTURE</p><h1>Make intellectual property <em>visible, measurable and financeable.</em></h1><div className="sub">A connected workspace to register, understand, value and commercialise intellectual property assets.</div><a href="http://localhost:8000/docs">Explore API documentation ↗</a></section><section className="heading"><div><small>PLATFORM MODULES</small><h2>One connected IP ecosystem</h2></div><span>12 MODULES</span></section><section className="grid">{modules.map(([name,desc],i)=><article key={name}><small>{String(i+1).padStart(2,"0")} <i>↗</i></small><h3>{name}</h3><p>{desc}</p></article>)}</section><footer>NEXTNEX IP WEALTH™ <span>Development environment · Sample interface</span></footer></main>}
